import sys
print("First name: " + sys.argv[1])