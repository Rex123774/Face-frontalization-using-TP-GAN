import streamlit as st
import requests
import base64
import io
from PIL import Image
import numpy as np


st.title("Image Generation")

input_image = st.file_uploader("Upload input image", type=["jpg", "jpeg", "png"])
if input_image is not None:
    # read the image file
    input_image = Image.open(input_image)

    # display the input image
    st.image(input_image, caption="Input image")

    if st.button("Generate Image"):
        # send a request to the server with the input image
        files = {"input_image": input_image}
        response = requests.post("http://localhost:8000/predict", files=files)

        # check if the request was successful
        if response.status_code == 200:
            # decode the base64 encoded image
            image = base64.b64decode(response.json()['image'])
            image = Image.open(io.BytesIO(image))
            execution_time = np.round(response.json()['time'],3)
            # display the generated image
            st.image(image, caption="Generated image")
            st.write("Execution time: ", execution_time, "seconds")
        else:
            st.error("Failed to generate image")
